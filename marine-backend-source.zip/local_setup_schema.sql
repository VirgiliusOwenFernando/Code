-- ============================================================
-- Reconstructed schema for marine_db (local dev)
--
-- Derived from: app/Models/*.php ($table/$allowedFields),
-- app/Database/Migrations/*.php (authoritative where present),
-- and every $db->table(...)->insert/update/select in app/Controllers.
--
-- This is a RECONSTRUCTION — the production server has the real
-- schema. Column types/constraints below are inferred from how the
-- code reads and writes each column. When you get a real dump from
-- the server, diff it against this file.
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS `marine_db`
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE `marine_db`;

-- ─────────────────────────────────────────────────────────────
-- MYTH/AUTH — users & groups
--
-- IMPORTANT: myth/auth v1.2.1 (the version locked in composer.lock) ships
-- an OLD migration (2017-11-20) whose schema does NOT match its own
-- models. The tables below are taken from the MODELS, because those are
-- what the framework actually reads and writes at runtime:
--   UserModel      -> users
--   LoginModel     -> auth_logins   (needs email/user_id/date/success)
--   GroupModel     -> auth_groups
--   PermissionModel-> auth_permissions
--   GroupModel::addUserToGroup -> auth_groups_users
-- ─────────────────────────────────────────────────────────────
CREATE TABLE `users` (
  `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`         VARCHAR(30) NOT NULL,
  `email`            VARCHAR(255) NOT NULL,
  -- The app writes these (CustomController, AuthApiController, ApiController
  -- joins `users.fullname`), but myth/auth's User entity does not declare
  -- them — they are extra columns on the production users table.
  `fullname`         VARCHAR(255) DEFAULT NULL,
  `phone`            VARCHAR(50) DEFAULT NULL,
  `given_names`      VARCHAR(255) DEFAULT NULL,
  `surname`          VARCHAR(255) DEFAULT NULL,
  `password_hash`    VARCHAR(255) NOT NULL,
  `reset_hash`       VARCHAR(255) DEFAULT NULL,
  `reset_at`         DATETIME DEFAULT NULL,
  `reset_expires`    DATETIME DEFAULT NULL,
  `activate_hash`    VARCHAR(255) DEFAULT NULL,
  `status`           VARCHAR(255) DEFAULT NULL,
  `status_message`   VARCHAR(255) DEFAULT NULL,
  `active`           TINYINT DEFAULT 0,
  `force_pass_reset` TINYINT DEFAULT 0,
  `permissions`      TEXT DEFAULT NULL,
  `deleted_at`       DATETIME DEFAULT NULL,
  `created_at`       DATETIME DEFAULT NULL,
  `updated_at`       DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `auth_identities` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED NOT NULL,
  `type`       VARCHAR(255) NOT NULL,
  `name`       VARCHAR(255) NOT NULL,
  `secret`     VARCHAR(255) NOT NULL,
  `created_at` DATETIME DEFAULT NULL,
  `updated_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type_name_secret` (`type`,`name`,`secret`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `auth_groups` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(255) NOT NULL,
  `description` VARCHAR(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `auth_permissions` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(255) NOT NULL,
  `description` VARCHAR(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `auth_users_permissions` (
  `user_id`       INT UNSIGNED NOT NULL,
  `permission_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`user_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `auth_groups_permissions` (
  `group_id`      INT UNSIGNED NOT NULL,
  `permission_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`group_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- auth_groups_users — REQUIRED: ApiController::isAdminUser() reads this
-- table directly to decide whether a bearer token belongs to an admin.
CREATE TABLE `auth_groups_users` (
  `group_id` INT UNSIGNED NOT NULL,
  `user_id`  INT UNSIGNED NOT NULL,
  PRIMARY KEY (`group_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- auth_logins — LoginModel::allowedFields = ip_address, email, user_id,
-- date, success (the packaged 2017 migration's column set is different).
CREATE TABLE `auth_logins` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ip_address` VARCHAR(255) NOT NULL DEFAULT '',
  `email`      VARCHAR(255) NOT NULL DEFAULT '',
  `user_id`    INT UNSIGNED DEFAULT NULL,
  `date`       DATETIME NOT NULL,
  `success`    TINYINT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `email` (`email`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `auth_tokens` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `selector`      VARCHAR(255) NOT NULL,
  `hashed_token`  VARCHAR(255) NOT NULL,
  `user_id`       INT UNSIGNED NOT NULL,
  `logged_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at`    DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `selector` (`selector`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `auth_reset_attempts` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ip_address` VARCHAR(255) NOT NULL,
  `user_agent` VARCHAR(255) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `auth_activation_attempts` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ip_address` VARCHAR(255) NOT NULL,
  `user_agent` VARCHAR(255) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- CORE MASTER DATA
-- ─────────────────────────────────────────────────────────────

-- boat — source: BoatModel, AdminCrudController::saveBoatFromRequest()
-- NOTE: AdminCrudController comments say "Schema declares photo1 NOT NULL"
CREATE TABLE `boat` (
  `id`        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `boat_name` VARCHAR(150) NOT NULL,
  `capacity`  INT NOT NULL DEFAULT 0,
  `photo1`    VARCHAR(255) NOT NULL DEFAULT '',
  `photo2`    VARCHAR(255) NOT NULL DEFAULT '',
  `photo3`    VARCHAR(255) NOT NULL DEFAULT '',
  `photo4`    VARCHAR(255) NOT NULL DEFAULT '',
  `photo5`    VARCHAR(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `boat_photo` (
  `id`      INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `boat_id` INT UNSIGNED NOT NULL,
  `url`     VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `boat_id` (`boat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- package — source: PackageModel, AdminCrudController::savePackageFromRequest()
CREATE TABLE `package` (
  `id`                    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title`                 VARCHAR(255) NOT NULL,
  `description`           TEXT DEFAULT NULL,
  `price_per_pax`         DECIMAL(12,2) NOT NULL DEFAULT 0,
  `price_per_pax_weekend` DECIMAL(12,2) DEFAULT NULL,
  `photo1`                VARCHAR(255) NOT NULL DEFAULT '',
  `photo2`                VARCHAR(255) NOT NULL DEFAULT '',
  `photo3`                VARCHAR(255) NOT NULL DEFAULT '',
  `pax_count`             INT NOT NULL DEFAULT 0,
  `status`                VARCHAR(20) NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- schedule — source: ScheduleModel, AdminCrudController::createSchedule()
-- `type` is DEPARTURE | RETURN; `total_pax` holds REMAINING slots
-- (ApiController::createPayment deducts jml_pax from it).
CREATE TABLE `schedule` (
  `id`        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `boat_id`   INT UNSIGNED NOT NULL,
  `type`      VARCHAR(20) NOT NULL DEFAULT 'DEPARTURE',
  `date`      DATE NOT NULL,
  `total_pax` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `boat_id` (`boat_id`),
  KEY `type` (`type`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- seat — source: SeatModel, ManifestUploadController::assignSeats()
-- `status` is 'available' | 'booked'
CREATE TABLE `seat` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `boat_id`     INT UNSIGNED NOT NULL,
  `seat_number` VARCHAR(20) NOT NULL,
  `status`      VARCHAR(20) NOT NULL DEFAULT 'available',
  PRIMARY KEY (`id`),
  KEY `boat_id` (`boat_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- booked_seats — source: BookedSeat model + Admin::insertBookedSeats()
-- NOTE: the model only lists payment_id+seat_id in $allowedFields, but the
-- controller also writes schedule_departure_id and booked_at.
CREATE TABLE `booked_seats` (
  `id`                    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `payment_id`            INT UNSIGNED NOT NULL,
  `schedule_departure_id` INT UNSIGNED DEFAULT NULL,
  `seat_id`               INT UNSIGNED NOT NULL,
  `booked_at`             DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_id` (`payment_id`),
  KEY `seat_id` (`seat_id`),
  KEY `schedule_departure_id` (`schedule_departure_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- booking_passengers — source: AddGroupBookingAndCleanup migration
-- + AddNikToBookingPassengers migration (adds `nik`)
CREATE TABLE `booking_passengers` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `payment_id` INT UNSIGNED NOT NULL,
  `name`       VARCHAR(150) NOT NULL,
  `nik`        VARCHAR(20) DEFAULT NULL,
  `seat_id`    INT UNSIGNED DEFAULT NULL,
  `created_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_id` (`payment_id`),
  KEY `seat_id` (`seat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- payments — source: Payment model + ApiController::createPayment/manualPayment
-- `status` values seen in code:
--   PENDING | PAID | SETTLED | ON VERIFICATION | REJECTED
-- `trip_type`: departure_only | return_only | departure_return
-- `payment_method`: xendit | manual
CREATE TABLE `payments` (
  `id`                    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`               INT UNSIGNED NOT NULL,
  `group_name`            VARCHAR(150) DEFAULT NULL,
  `checkout_link`         VARCHAR(255) DEFAULT NULL,
  `external_id`           VARCHAR(255) DEFAULT NULL,
  `jml_pax`               INT NOT NULL DEFAULT 0,
  `package_id`            INT UNSIGNED DEFAULT NULL,
  `package_name`          VARCHAR(255) DEFAULT NULL,
  `schedule_return_id`    INT UNSIGNED DEFAULT NULL,
  `schedule_departure_id` INT UNSIGNED DEFAULT NULL,
  `status`                VARCHAR(30) NOT NULL DEFAULT 'PENDING',
  `amount`                BIGINT NOT NULL DEFAULT 0,
  `trip_type`             VARCHAR(30) DEFAULT 'departure_only',
  `qr_code`               VARCHAR(255) DEFAULT NULL,
  `attendance`            TINYINT DEFAULT 0,
  `transfer_slip`         VARCHAR(255) DEFAULT NULL,
  `payer_email`           VARCHAR(255) DEFAULT NULL,
  `payment_method`        VARCHAR(30) DEFAULT NULL,
  `created_at`            DATETIME DEFAULT NULL,
  `updated_at`            DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  KEY `schedule_departure_id` (`schedule_departure_id`),
  KEY `schedule_return_id` (`schedule_return_id`),
  KEY `external_id` (`external_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- api_tokens — source: CreateApiTokensTable migration
-- `token` stores the SHA-256 hex of the bearer token (64 chars).
CREATE TABLE `api_tokens` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED NOT NULL,
  `token`      VARCHAR(64) NOT NULL,
  `expires_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `token` (`token`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- CONTENT / CMS TABLES
-- ─────────────────────────────────────────────────────────────

CREATE TABLE `home` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `jb_photo`    VARCHAR(255) DEFAULT NULL,
  `jb_title`    VARCHAR(255) DEFAULT NULL,
  `jb_desc`     TEXT DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- home_gallery — source: CreateHomeGalleryTable migration
CREATE TABLE `home_gallery` (
  `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `photo`          VARCHAR(255) NOT NULL,
  `alt_text`       VARCHAR(255) DEFAULT NULL,
  `column_position` ENUM('left','center','right') NOT NULL DEFAULT 'left',
  `media_type`     ENUM('image','video') NOT NULL DEFAULT 'image',
  `sort_order`     INT NOT NULL DEFAULT 0,
  `is_active`      TINYINT NOT NULL DEFAULT 1,
  `created_at`     DATETIME DEFAULT NULL,
  `updated_at`     DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `column_position` (`column_position`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `aboutus` (
  `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `jb_photo`       VARCHAR(255) DEFAULT NULL,
  `jb_title`       VARCHAR(255) DEFAULT NULL,
  `jb_description` TEXT DEFAULT NULL,
  `as_title`       VARCHAR(255) DEFAULT NULL,
  `as_description` TEXT DEFAULT NULL,
  `as_photo`       VARCHAR(255) DEFAULT NULL,
  `as_name`        VARCHAR(255) DEFAULT NULL,
  `as_position`    VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `footer` (
  `id`        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `day_op`    VARCHAR(255) DEFAULT NULL,
  `phone`     VARCHAR(255) DEFAULT NULL,
  `copyright` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `routes` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `route_name` VARCHAR(255) NOT NULL,
  `price`      BIGINT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- departure_schedule / return_schedule — source: DepartureModel, ReturnModel
CREATE TABLE `departure_schedule` (
  `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `package_id`      INT UNSIGNED NOT NULL,
  `departure_date`  DATE NOT NULL,
  `departure_time`  TIME NOT NULL,
  `available_slots` INT NOT NULL DEFAULT 0,
  `created_at`      DATETIME DEFAULT NULL,
  `updated_at`      DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `package_id` (`package_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `return_schedule` (
  `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `package_id`     INT UNSIGNED NOT NULL,
  `return_date`    DATE NOT NULL,
  `return_time`    TIME NOT NULL,
  `available_slots` INT NOT NULL DEFAULT 0,
  `created_at`     DATETIME DEFAULT NULL,
  `updated_at`     DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `package_id` (`package_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `package_schedule` (
  `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `package_id`      INT UNSIGNED NOT NULL,
  `departure_date`  DATE DEFAULT NULL,
  `available_slots` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `package_id` (`package_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- MANIFEST / CREW
-- ─────────────────────────────────────────────────────────────

-- manifest_uploads — source: ManifestUploadModel + AddMetadataToManifestUploads
CREATE TABLE `manifest_uploads` (
  `id`                   INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `schedule_id`          INT UNSIGNED DEFAULT NULL,
  `boat_id`              INT UNSIGNED DEFAULT NULL,
  `direction`            VARCHAR(20) NOT NULL DEFAULT 'DEPARTURE',
  `trip_date`            DATE DEFAULT NULL,
  `boat_name`            VARCHAR(255) DEFAULT NULL,
  `origin`               VARCHAR(100) DEFAULT NULL,
  `destination`          VARCHAR(100) DEFAULT NULL,
  `captain_name`         VARCHAR(255) DEFAULT NULL,
  `abk_names`            TEXT DEFAULT NULL,
  `gro_name`             VARCHAR(200) DEFAULT NULL,
  `uploaded_by`          INT UNSIGNED DEFAULT NULL,
  `original_file`        VARCHAR(255) DEFAULT NULL,
  `total_pax`            INT DEFAULT 0,
  `overnight_count`      INT DEFAULT NULL,
  `daytrip_count`        INT DEFAULT NULL,
  `staff_count`          INT DEFAULT 0,
  `foc_count`            INT DEFAULT 0,
  `vendor_count`         INT DEFAULT 0,
  `status`               VARCHAR(20) NOT NULL DEFAULT 'draft',
  `notes`                TEXT DEFAULT NULL,
  `group_qr_codes`       LONGTEXT DEFAULT NULL,
  `qr_generation_status` VARCHAR(20) DEFAULT NULL,
  `qr_emails_sent_at`    DATETIME DEFAULT NULL,
  `created_at`           DATETIME DEFAULT NULL,
  `updated_at`           DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `schedule_id` (`schedule_id`),
  KEY `direction` (`direction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- manifest_tickets — source: ManifestTicketModel + AddEmailToManifestTickets
CREATE TABLE `manifest_tickets` (
  `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `upload_id`      INT UNSIGNED NOT NULL,
  `schedule_id`    INT UNSIGNED DEFAULT NULL,
  `boat_id`        INT UNSIGNED DEFAULT NULL,
  `direction`      VARCHAR(20) NOT NULL DEFAULT 'DEPARTURE',
  `trip_date`      DATE DEFAULT NULL,
  `seq_no`         INT NOT NULL DEFAULT 0,
  `ket`            VARCHAR(50) DEFAULT NULL,
  `passenger_name` VARCHAR(255) NOT NULL,
  `group_name`     VARCHAR(255) DEFAULT NULL,
  `email`          VARCHAR(255) DEFAULT NULL,
  `agent`          VARCHAR(255) DEFAULT NULL,
  `package`        VARCHAR(255) DEFAULT NULL,
  `pax_count`      INT DEFAULT 1,
  `notes`          TEXT DEFAULT NULL,
  `age`            INT DEFAULT NULL,
  `gender`         VARCHAR(20) DEFAULT NULL,
  `domicile`       VARCHAR(255) DEFAULT NULL,
  `id_passport`    VARCHAR(50) DEFAULT NULL,
  `seat_id`        INT UNSIGNED DEFAULT NULL,
  `seat_number`    VARCHAR(20) DEFAULT NULL,
  `ticket_code`    VARCHAR(100) DEFAULT NULL,
  `checked_in`     TINYINT NOT NULL DEFAULT 0,
  `checked_in_at`  DATETIME DEFAULT NULL,
  `cancelled`      TINYINT NOT NULL DEFAULT 0,
  `created_at`     DATETIME DEFAULT NULL,
  `updated_at`     DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `upload_id` (`upload_id`),
  KEY `schedule_id` (`schedule_id`),
  KEY `ticket_code` (`ticket_code`),
  KEY `group_name` (`group_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- manifest_baggage — source: ManifestBaggageModel
CREATE TABLE `manifest_baggage` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `upload_id`   INT UNSIGNED NOT NULL,
  `schedule_id` INT UNSIGNED DEFAULT NULL,
  `trip_date`   DATE DEFAULT NULL,
  `group_name`  VARCHAR(255) DEFAULT NULL,
  `bag_label`   VARCHAR(255) DEFAULT NULL,
  `weight_kg`   DECIMAL(8,2) DEFAULT NULL,
  `bag_count`   INT NOT NULL DEFAULT 1,
  `description` TEXT DEFAULT NULL,
  `direction`   VARCHAR(20) DEFAULT 'DEPARTURE',
  `tag_printed` TINYINT NOT NULL DEFAULT 0,
  `created_at`  DATETIME DEFAULT NULL,
  `updated_at`  DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `upload_id` (`upload_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- manifest_group_checkins — source: CreateManifestGroupCheckinsTable migration
CREATE TABLE `manifest_group_checkins` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `upload_id`     INT UNSIGNED NOT NULL,
  `group_name`    VARCHAR(255) NOT NULL,
  `checked_in_at` DATETIME NOT NULL,
  `direction`     ENUM('DEPARTURE','RETURN') NOT NULL DEFAULT 'DEPARTURE',
  `notes`         TEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `upload_id_group_name` (`upload_id`,`group_name`),
  KEY `checked_in_at` (`checked_in_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- crew — source: CreateCrewTables migration
CREATE TABLE `crew` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(150) NOT NULL,
  `role`       ENUM('captain','abk','gro','staff','other') NOT NULL DEFAULT 'abk',
  `phone`      VARCHAR(30) DEFAULT NULL,
  `id_number`  VARCHAR(50) DEFAULT NULL,
  `notes`      TEXT DEFAULT NULL,
  `qr_code`    VARCHAR(80) DEFAULT NULL,
  `active`     TINYINT NOT NULL DEFAULT 1,
  `created_at` DATETIME DEFAULT NULL,
  `updated_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `qr_code` (`qr_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `crew_assignments` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `crew_id`     INT UNSIGNED NOT NULL,
  `schedule_id` INT UNSIGNED DEFAULT NULL,
  `boat_id`     INT UNSIGNED DEFAULT NULL,
  `trip_date`   DATE DEFAULT NULL,
  `direction`   ENUM('DEPARTURE','RETURN','BOTH') NOT NULL DEFAULT 'DEPARTURE',
  `notes`       TEXT DEFAULT NULL,
  `created_at`  DATETIME DEFAULT NULL,
  `updated_at`  DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crew_id` (`crew_id`),
  KEY `schedule_id` (`schedule_id`),
  KEY `trip_date` (`trip_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `crew_checkins` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `crew_id`       INT UNSIGNED NOT NULL,
  `assignment_id` INT UNSIGNED DEFAULT NULL,
  `schedule_id`   INT UNSIGNED DEFAULT NULL,
  `checked_in_at` DATETIME DEFAULT NULL,
  `note`          VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crew_id` (`crew_id`),
  KEY `assignment_id` (`assignment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
