<?php

namespace App\Models;

use Myth\Auth\Models\UserModel as MythUserModel;

/**
 * Users table for nama_mrn includes profile columns not in stock Myth\Auth.
 */
class UserModel extends MythUserModel
{
    protected $allowedFields = [
        'email',
        'username',
        'password_hash',
        'reset_hash',
        'reset_at',
        'reset_expires',
        'activate_hash',
        'status',
        'status_message',
        'active',
        'force_pass_reset',
        'deleted_at',
        'fullname',
        'phone',
        'user_image',
    ];
}
