<?php

namespace App\Controllers;

use App\Models\ApiTokenModel;
use App\Models\UserModel;
use Myth\Auth\Authorization\GroupModel;
use Myth\Auth\Entities\User;

/**
 * AuthApiController
 *
 * Token-based auth endpoints for the React frontend.
 * Uses myth/auth for credential validation but issues a Bearer token
 * so that React can stay stateless (no PHP session cookies needed).
 *
 * Routes (add to Routes.php):
 *   POST /api/auth/login
 *   POST /api/auth/register
 *   POST /api/auth/logout      (requires Bearer token)
 *   GET  /api/auth/me          (requires Bearer token)
 */
class AuthApiController extends BaseController
{
    private const ALLOWED_ORIGINS = [
        'http://localhost:3000',
        'http://localhost:5173',
        'http://localhost:5174',
        'https://namamarine.cloud',
        'http://namamarine.cloud',
        'https://www.namamarine.cloud',
    ];

    private function getAllowedOrigin(): string
    {
        $origin = $this->request->getHeaderLine('Origin');
        return in_array($origin, self::ALLOWED_ORIGINS, true) ? $origin : self::ALLOWED_ORIGINS[0];
    }

    private function json(array $data, int $status = 200)
    {
        return $this->response
            ->setStatusCode($status)
            ->setHeader('Content-Type', 'application/json')
            ->setHeader('Access-Control-Allow-Origin', $this->getAllowedOrigin())
            ->setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            ->setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization')
            ->setHeader('Access-Control-Allow-Credentials', 'true')
            ->setJSON($data);
    }

    private function error(string $message, int $status = 400): \CodeIgniter\HTTP\Response
    {
        return $this->json(['error' => $message], $status);
    }

    public function options()
    {
        $origin = $this->request->getHeaderLine('Origin');
        $allowed = in_array($origin, self::ALLOWED_ORIGINS, true) ? $origin : self::ALLOWED_ORIGINS[0];

        return $this->response
            ->setStatusCode(200)
            ->setHeader('Access-Control-Allow-Origin', $allowed)
            ->setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            ->setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization')
            ->setHeader('Access-Control-Allow-Credentials', 'true')
            ->setBody('');
    }

    /** Extract Bearer token from Authorization header. */
    private function bearerToken(): ?string
    {
        $header = $this->request->getHeaderLine('Authorization');
        if (str_starts_with($header, 'Bearer ')) {
            return substr($header, 7);
        }
        return null;
    }

    /** Resolve authenticated user from Bearer token or return null. */
    private function authUser(): ?array
    {
        $raw = $this->bearerToken();
        if (!$raw) return null;

        $tokenModel = new ApiTokenModel();
        $row = $tokenModel->findValid($raw);
        if (!$row) return null;

        $userModel = new UserModel();
        $user = $userModel->find($row['user_id']);
        if (!$user) return null;

        // find() returns a Myth\Auth\Entities\User entity (returnType is the
        // entity class, not 'array'). Casting an Entity with (array) only
        // exposes its *declared* properties, so the real user fields stay
        // locked inside $attributes and come out as mangled \0*\0 keys.
        // toRawArray() is the supported way to get the actual column data.
        return method_exists($user, 'toRawArray') ? $user->toRawArray() : (array) $user;
    }

    // ── POST /api/auth/login ──────────────────────────────────────

    public function login()
    {
        $email    = trim($this->request->getJSON(true)['email']    ?? '');
        $password = trim($this->request->getJSON(true)['password'] ?? '');

        if (!$email || !$password) {
            return $this->error('Email and password are required.');
        }

        /** @var \Myth\Auth\Authentication\LocalAuthenticator $auth */
        $auth = service('authentication');

        if (!$auth->attempt(['email' => $email, 'password' => $password])) {
            return $this->error('Invalid email or password.', 401);
        }

        $user       = $auth->user();
        $tokenModel = new ApiTokenModel();
        $rawToken   = $tokenModel->generateFor((int) $user->id);

        $groups = (new GroupModel())->getGroupsForUser((int) $user->id);
        $role   = in_array('admin', array_column($groups, 'name'), true) ? 'admin' : 'users';

        return $this->json([
            'token' => $rawToken,
            'user'  => [
                'id'       => (int) $user->id,
                'username' => $user->username,
                'email'    => $user->email,
                'fullname' => $user->fullname ?? '',
                'phone'    => $user->phone    ?? '',
                'role'     => $role,
            ],
        ]);
    }

    // ── POST /api/auth/register ───────────────────────────────────

    public function register()
    {
        $body = $this->request->getJSON(true) ?? [];

        $username       = trim($body['username']         ?? '');
        $fullname       = trim($body['fullname']         ?? '');
        $email          = trim($body['email']            ?? '');
        $phone          = trim($body['phone']            ?? '');
        $password       = $body['password']              ?? '';
        $passConfirm    = $body['password_confirm']      ?? '';

        // Basic validation
        if (!$username || !$fullname || !$email || !$phone || !$password) {
            return $this->error('All fields are required.');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return $this->error('Invalid email address.');
        }
        if ($password !== $passConfirm) {
            return $this->error('Passwords do not match.');
        }
        if (strlen($password) < 8) {
            return $this->error('Password must be at least 8 characters.');
        }

        $userModel = new UserModel();

        // Check uniqueness
        if ($userModel->where('email', $email)->first()) {
            return $this->error('Email is already registered.', 409);
        }
        if ($userModel->where('username', $username)->first()) {
            return $this->error('Username is already taken.', 409);
        }

        // Normalise phone to +62
        if (str_starts_with($phone, '0')) {
            $phone = '+62' . substr($phone, 1);
        } elseif (!str_starts_with($phone, '+62')) {
            $phone = '+62' . $phone;
        }

        $user = new User([
            'username'     => $username,
            'email'        => $email,
            'password'     => $password,
            'pass_confirm' => $password,
            'fullname'     => $fullname,
            'phone'        => $phone,
            'user_image'   => 'default.svg',
        ]);
        $user->activate(); // no email activation required

        $config = config('Auth');
        if (!empty($config->defaultUserGroup)) {
            $userModel = $userModel->withGroup($config->defaultUserGroup);
        }

        if (!$userModel->save($user)) {
            return $this->error(implode(', ', $userModel->errors()), 422);
        }

        return $this->json(['message' => 'Registration successful. You can now log in.'], 201);
    }

    // ── POST /api/auth/logout ─────────────────────────────────────

    public function logout()
    {
        $raw = $this->bearerToken();
        if ($raw) {
            $tokenModel = new ApiTokenModel();
            $row = $tokenModel->findValid($raw);
            if ($row) {
                $tokenModel->revokeFor((int) $row['user_id']);
            }
        }
        return $this->json(['message' => 'Logged out successfully.']);
    }

    // ── GET /api/auth/me ──────────────────────────────────────────

    public function me()
    {
        $user = $this->authUser();
        if (!$user) {
            return $this->error('Unauthenticated.', 401);
        }

        // Read the roles straight from GroupModel instead of going through
        // Myth\Auth\Entities\User. The entity cannot be rebuilt from a row
        // array: its fill() would route the `permissions` column through
        // User::setPermissions(), which always throws.
        $groups  = \Myth\Auth\Authorization\GroupModel::class;
        $groups  = (new $groups())->getGroupsForUser((int) $user['id']);
        $role    = in_array('admin', array_column($groups, 'name'), true) ? 'admin' : 'users';

        return $this->json([
            'id'       => (int) $user['id'],
            'username' => $user['username'],
            'email'    => $user['email'],
            'fullname' => $user['fullname'] ?? '',
            'phone'    => $user['phone']    ?? '',
            'role'     => $role,
        ]);
    }
}
