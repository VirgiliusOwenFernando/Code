<?php
// List users + their auth groups in a given database. Usage: php list_users.php [db]
$db = $argv[1] ?? 'nama_mrn';

$mysqli = new mysqli('127.0.0.1', 'root', '', $db);
if ($mysqli->connect_error) {
    fwrite(STDERR, "connect failed: {$mysqli->connect_error}\n");
    exit(1);
}

$res = $mysqli->query(
    "SELECT u.id, u.username, u.email, u.fullname, u.active, u.status,
            GROUP_CONCAT(g.name ORDER BY g.id SEPARATOR ', ') AS groups
     FROM users u
     LEFT JOIN auth_groups_users agu ON agu.user_id = u.id
     LEFT JOIN auth_groups g ON g.id = agu.group_id
     GROUP BY u.id
     ORDER BY u.id"
);

while ($r = $res->fetch_assoc()) {
    printf(
        "id=%-3s %-22s %-34s %-26s active=%-3s groups=%s\n",
        $r['id'],
        $r['username'],
        $r['email'],
        $r['fullname'] ?? '-',
        $r['active'] ?? '-',
        $r['groups'] ?? '(none)'
    );
}

echo "\n-- auth_groups --\n";
$g = $mysqli->query("SELECT id, name, description FROM auth_groups ORDER BY id");
while ($r = $g->fetch_assoc()) {
    echo "  id={$r['id']} {$r['name']} — {$r['description']}\n";
}
