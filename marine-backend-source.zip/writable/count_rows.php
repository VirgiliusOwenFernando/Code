<?php
// Row-count report for an imported database. Usage: php count_rows.php [db]
$db = $argv[1] ?? 'nama_mrn';

$mysqli = new mysqli('127.0.0.1', 'root', '', $db);
if ($mysqli->connect_error) {
    fwrite(STDERR, "connect failed: {$mysqli->connect_error}\n");
    exit(1);
}

$res = $mysqli->query(
    "SELECT table_name FROM information_schema.tables WHERE table_schema = '"
    . $mysqli->real_escape_string($db)
    . "' ORDER BY table_name"
);

$total = 0;
$rows  = [];

while ($t = $res->fetch_assoc()) {
    $name = $t['table_name'];
    $c    = $mysqli->query("SELECT COUNT(*) AS c FROM `{$name}`")->fetch_assoc()['c'];
    $total++;
    if ($c > 0) {
        $rows[] = sprintf('  %-24s %8d', $name, $c);
    }
}

echo "Database: {$db}\n";
echo "Tables: {$total}\n\n";
echo implode("\n", $rows), "\n";
