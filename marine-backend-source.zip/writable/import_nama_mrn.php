<?php
/**
 * One-off import for D:/nama_mrn.sql — run: php writable/import_nama_mrn.php
 */
$host = '127.0.0.1';
$user = 'root';
$pass = '';
$sqlFile = 'D:/nama_mrn.sql';
$targetDb = 'nama_mrn';
$mysqlBin = 'C:/xampp/mysql/bin/mysql.exe';

if (!is_file($sqlFile)) {
    fwrite(STDERR, "File not found: $sqlFile\n");
    exit(1);
}

$mysqli = new mysqli($host, $user, $pass);
if ($mysqli->connect_error) {
    fwrite(STDERR, "Connect failed: {$mysqli->connect_error}\n");
    exit(1);
}

$mysqli->query('SET GLOBAL max_allowed_packet=1073741824');
$mysqli->query("CREATE DATABASE IF NOT EXISTS `$targetDb` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
if ($mysqli->error) {
    fwrite(STDERR, "Create DB: {$mysqli->error}\n");
    exit(1);
}
$mysqli->close();

$cleanFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'nama_mrn_import.sql';
$in = fopen($sqlFile, 'rb');
$out = fopen($cleanFile, 'wb');
if (!$in || !$out) {
    fwrite(STDERR, "Cannot open files for cleaning\n");
    exit(1);
}
$first = true;
while (($line = fgets($in)) !== false) {
    if ($first) {
        $first = false;
        if (str_contains($line, 'sandbox mode')) {
            continue;
        }
    }
    fwrite($out, $line);
}
fclose($in);
fclose($out);

$cmd = sprintf(
    '"%s" -h %s -u %s %s %s < "%s"',
    $mysqlBin,
    $host,
    $user,
    $pass === '' ? '' : '-p' . escapeshellarg($pass),
    escapeshellarg($targetDb),
    $cleanFile
);

// Windows: use cmd redirect
$winCmd = sprintf('cmd /c ""%s" -h %s -u %s --max_allowed_packet=512M %s < "%s""', $mysqlBin, $host, $user, $targetDb, $cleanFile);
passthru($winCmd, $code);
@unlink($cleanFile);

if ($code !== 0) {
    fwrite(STDERR, "mysql import exited with code $code\n");
    exit($code);
}

$mysqli = new mysqli($host, $user, $pass, $targetDb);
$res = $mysqli->query("SELECT COUNT(*) AS c FROM information_schema.tables WHERE table_schema='$targetDb'");
$row = $res->fetch_assoc();
echo "Import OK into `$targetDb`: {$row['c']} tables\n";
